package com.example.core.utils

object Constants {
    const val SHARED_PACKAGE = "base_shared_preferences"
    const val PIXABAY_KEY = "25007027-7418deb977c638792f4bfb99f"
    const val PIXABAY_BASE_URL = "https://pixabay.com"
    const val TRANSLATION_BASE_URL =
        "https://translated-mymemory---translation-memory.p.rapidapi.com"
    const val TRANSLATION_KEY = "78bb8ecc8dmsha71f7db1db6c66cp1338f5jsn2ae3a25d70d2"
}