package com.example.endo.models

data class BoardModel (
    val lottieName:String,
    val title:String,
    val description:String,
        )