package com.example.endo.fragments.boardingflow

interface PagerListener {
    fun onStartClick()
}