package com.example.endo.models

data class CategoryModel (
    val category:String
        )